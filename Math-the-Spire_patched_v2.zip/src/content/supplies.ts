// src/content/supplies.ts
export type SupplyDef = {
  id: string;
  name: string;
  desc: string;
};

export const SUPPLIES_POOL_10: SupplyDef[] = [
  { id: "sup_calc", name: "Calculator", desc: "Once per battle: reroll a question." },
  { id: "sup_ruler", name: "Ruler", desc: "+1 Block on the first turn of each battle." },
  { id: "sup_eraser", name: "Eraser", desc: "First wrong answer each battle has reduced penalty." },
  { id: "sup_pencil", name: "Mechanical Pencil", desc: "+1 Power to your first correct answer each turn." },
  { id: "sup_highlighter", name: "Highlighter", desc: "Hints are slightly stronger (future)." },
  { id: "sup_notebook", name: "Notebook", desc: "Start each battle with +1 card draw (future)." },
  { id: "sup_agenda", name: "Agenda", desc: "Reveal enemy intent more clearly (future)." },
  { id: "sup_compass", name: "Compass", desc: "Overworld: see one extra node ahead (future)." },
  { id: "sup_usb", name: "USB Drive", desc: "Save a bonus (future)." },
  { id: "sup_glue", name: "Glue Stick", desc: "Small passive defense (future)." },
];
