// src/content/cards.ts
export type CardType = "ATTACK" | "BLOCK" | "SKILL";

export type CardDef = {
  id: string;
  name: string;
  type: CardType;
  desc: string;
  // Placeholder for future battle hooks:
  // e.g. "onPlay": "damage", "block", "draw", etc.
  hook?: { kind: string; base: number };
};

export const STARTER_POOL_20: CardDef[] = [
  { id: "atk_strike", name: "Strike", type: "ATTACK", desc: "Deal damage. Power scales with correct answers.", hook: { kind: "damage", base: 6 } },
  { id: "atk_heavy", name: "Heavy Hit", type: "ATTACK", desc: "Deal big damage. Costs tougher questions.", hook: { kind: "damage", base: 10 } },
  { id: "atk_multi", name: "Rapid Fire", type: "ATTACK", desc: "Deal small damage 2x.", hook: { kind: "damage_multi", base: 4 } },
  { id: "atk_pierce", name: "Piercing Shot", type: "ATTACK", desc: "Deal damage that ignores some block.", hook: { kind: "pierce", base: 7 } },
  { id: "atk_combo", name: "Combo", type: "ATTACK", desc: "If you answered correctly last turn, deal extra damage.", hook: { kind: "combo", base: 6 } },

  { id: "blk_guard", name: "Guard", type: "BLOCK", desc: "Gain block. Power scales with correct answers.", hook: { kind: "block", base: 6 } },
  { id: "blk_wall", name: "Wall Up", type: "BLOCK", desc: "Gain lots of block. Costs tougher questions.", hook: { kind: "block", base: 10 } },
  { id: "blk_reflex", name: "Reflex", type: "BLOCK", desc: "Gain block, then draw 1 card.", hook: { kind: "block_draw", base: 5 } },
  { id: "blk_counter", name: "Counter", type: "BLOCK", desc: "Gain block; next attack deals bonus damage.", hook: { kind: "counter", base: 4 } },
  { id: "blk_shield", name: "Shield Bash", type: "BLOCK", desc: "Gain small block and deal small damage.", hook: { kind: "block_damage", base: 4 } },

  { id: "skl_focus", name: "Focus", type: "SKILL", desc: "Reroll a question once this turn.", hook: { kind: "reroll", base: 1 } },
  { id: "skl_hint", name: "Hint Token", type: "SKILL", desc: "Get a hint (future: reveals step / narrows choices).", hook: { kind: "hint", base: 1 } },
  { id: "skl_draw2", name: "Quick Thinking", type: "SKILL", desc: "Draw 2 cards.", hook: { kind: "draw", base: 2 } },
  { id: "skl_mulligan", name: "Mulligan", type: "SKILL", desc: "Discard 1 card, draw 1 card.", hook: { kind: "cycle", base: 1 } },
  { id: "skl_boost", name: "Confidence", type: "SKILL", desc: "Next correct answer is worth extra power.", hook: { kind: "boost", base: 1 } },

  { id: "atk_risk", name: "All-In", type: "ATTACK", desc: "If correct, huge damage. If wrong, lose some block.", hook: { kind: "risk_damage", base: 14 } },
  { id: "blk_risk", name: "Last Stand", type: "BLOCK", desc: "If correct, big block. If wrong, take chip damage.", hook: { kind: "risk_block", base: 14 } },
  { id: "skl_clean", name: "Clean Notes", type: "SKILL", desc: "Remove a negative effect (future).", hook: { kind: "cleanse", base: 1 } },
  { id: "skl_upgrade", name: "Study Session", type: "SKILL", desc: "Upgrade a random card (future).", hook: { kind: "upgrade", base: 1 } },
  { id: "skl_free", name: "Free Period", type: "SKILL", desc: "Gain a small bonus this turn (future).", hook: { kind: "tempo", base: 1 } },
];

export const ALL_CARDS_40ish: CardDef[] = [
  ...STARTER_POOL_20,
  // Later you can extend here up to 30–40 cards.
];
