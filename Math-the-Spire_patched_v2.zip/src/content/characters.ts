// src/content/characters.ts
export type CharacterPreset = {
  id: string;
  name: string;
  emoji: string;
  tagline: string;
};

export const CHARACTERS_3: CharacterPreset[] = [
  { id: "char_astronaut", name: "Astro", emoji: "🧑‍🚀", tagline: "Curious. Bold. Loves challenges." },
  { id: "char_knight", name: "Knight", emoji: "🛡️", tagline: "Steady. Calm. Blocks like a pro." },
  { id: "char_wizard", name: "Wizard", emoji: "🧙‍♂️", tagline: "Smart. Sneaky. Finds patterns fast." },
];
