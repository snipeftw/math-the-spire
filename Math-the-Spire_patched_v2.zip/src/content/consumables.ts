// src/content/consumables.ts
export type ConsumableDef = {
  id: string;
  name: string;
  desc: string;
};

export const CONSUMABLES_10: ConsumableDef[] = [
  { id: "con_apple", name: "Apple", desc: "Heal a small amount (future)." },
  { id: "con_granola", name: "Granola Bar", desc: "Gain small block (future)." },
  { id: "con_juice", name: "Juice Box", desc: "Gain small power (future)." },
  { id: "con_sandwich", name: "Sandwich", desc: "Heal more (future)." },
  { id: "con_cookie", name: "Cookie", desc: "Draw 1 card (future)." },
  { id: "con_yogurt", name: "Yogurt", desc: "Remove a debuff (future)." },
  { id: "con_trailmix", name: "Trail Mix", desc: "Boost next correct answer (future)." },
  { id: "con_water", name: "Water Bottle", desc: "Stabilize penalties for wrong answers (future)." },
  { id: "con_chips", name: "Chips", desc: "Risk/reward buff (future)." },
  { id: "con_banana", name: "Banana", desc: "Small heal + small power (future)." },
];
