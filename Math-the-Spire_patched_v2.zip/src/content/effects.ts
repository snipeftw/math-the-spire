// src/content/effects.ts
export type EffectDef = {
  id: string;
  icon: string;
  name: string;
  description: string;
  // How stacking should behave (for later):
  stacking?: "stack" | "refresh" | "none";
};

export const EFFECTS: EffectDef[] = [
  {
    id: "weak",
    icon: "🪶",
    name: "Weak",
    description: "Deals 25% less damage with attacks.",
    stacking: "stack",
  },
  {
    id: "vulnerable",
    icon: "🎯",
    name: "Vulnerable",
    description: "Takes 25% more damage from attacks.",
    stacking: "stack",
  },
  {
    id: "poison",
    icon: "☠️",
    name: "Poison",
    description: "At end of turn, lose HP equal to stacks. Then stacks decrease by 1.",
    stacking: "stack",
  },
  {
    id: "regen",
    icon: "🌿",
    name: "Regen",
    description: "At end of turn, heal HP equal to stacks. Then stacks decrease by 1.",
    stacking: "stack",
  },
];

const byId = new Map(EFFECTS.map((e) => [e.id, e] as const));

export function getEffectDef(id: string | undefined | null): EffectDef | undefined {
  if (!id) return undefined;
  return byId.get(id);
}
