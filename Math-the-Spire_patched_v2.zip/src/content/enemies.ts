// src/content/enemies.ts
import type { SpriteRef, EnemyState, Status } from "../game/battle";
import type { RNG } from "../game/rng";
import { pick } from "../game/rng";

export type EncounterDef = {
  id: string;
  name: string;
  enemies: Array<{
    id: string;
    name: string;
    hp: number;
    maxHP: number;
    intentDamage: number;
    sprite: SpriteRef;
    statuses?: Status[];
  }>;
};

// --- Helpers ---
function e(
  id: string,
  name: string,
  hp: number,
  intentDamage: number,
  sprite: SpriteRef,
  statuses: Status[] = []
): EncounterDef["enemies"][number] {
  return { id, name, hp, maxHP: hp, intentDamage, sprite, statuses };
}

// Pool 1 (depth 1–3): easy encounters (5)
export const ENCOUNTER_POOL_EASY_5: EncounterDef[] = [
  { id: "easy_slime", name: "Wobbly Slime", enemies: [e("slime", "Slime", 26, 5, { kind: "emoji", value: "🟢" })] },
  { id: "easy_ghost", name: "Shy Ghost", enemies: [e("ghost", "Ghost", 24, 6, { kind: "emoji", value: "👻" })] },
  { id: "easy_bug", name: "Math Mite", enemies: [e("mite", "Mite", 22, 6, { kind: "emoji", value: "🪲" })] },
  { id: "easy_duo", name: "Twin Sprites", enemies: [
      e("sprite_a", "Sprite A", 14, 3, { kind: "emoji", value: "✨" }),
      e("sprite_b", "Sprite B", 14, 3, { kind: "emoji", value: "💫" }),
    ] },
  { id: "easy_bat", name: "Ceiling Bat", enemies: [e("bat", "Bat", 20, 7, { kind: "emoji", value: "🦇" })] },
];

// Pool 2 (depth 4–6): medium encounters (5)
export const ENCOUNTER_POOL_MED_5: EncounterDef[] = [
  { id: "med_golem", name: "Stone Golem", enemies: [e("golem", "Golem", 34, 8, { kind: "emoji", value: "🗿" })] },
  { id: "med_wolf", name: "Hungry Wolf", enemies: [e("wolf", "Wolf", 32, 9, { kind: "emoji", value: "🐺" })] },
  { id: "med_trio", name: "Number Gremlins", enemies: [
      e("g1", "Gremlin", 18, 4, { kind: "emoji", value: "👺" }),
      e("g2", "Gremlin", 18, 4, { kind: "emoji", value: "👺" }),
    ] },
  { id: "med_mage", name: "Quiz Mage", enemies: [e("mage", "Mage", 30, 10, { kind: "emoji", value: "🧙" })] },
  { id: "med_armor", name: "Animated Armor", enemies: [e("armor", "Armor", 36, 8, { kind: "emoji", value: "🛡️" })] },
];

// Pool 3 (depth 7+): hard encounters (5)
export const ENCOUNTER_POOL_HARD_5: EncounterDef[] = [
  { id: "hard_ogre", name: "Ogre Brute", enemies: [e("ogre", "Ogre", 44, 12, { kind: "emoji", value: "👹" })] },
  { id: "hard_drake", name: "Crimson Drake", enemies: [e("drake", "Drake", 42, 13, { kind: "emoji", value: "🐲" })] },
  { id: "hard_duo_tanks", name: "Twin Terrors", enemies: [
      e("t1", "Terror", 26, 7, { kind: "emoji", value: "😈" }),
      e("t2", "Terror", 26, 7, { kind: "emoji", value: "😈" }),
    ] },
  { id: "hard_shaman", name: "Storm Shaman", enemies: [e("shaman", "Shaman", 40, 14, { kind: "emoji", value: "🧿" })] },
  { id: "hard_swarm", name: "Swarm", enemies: [
      e("s1", "Drone", 18, 5, { kind: "emoji", value: "🐝" }),
      e("s2", "Drone", 18, 5, { kind: "emoji", value: "🐝" }),
      e("s3", "Drone", 18, 5, { kind: "emoji", value: "🐝" }),
    ] },
];

export const BOSS_ENCOUNTER: EncounterDef = {
  id: "boss_examiner",
  name: "The Examiner",
  enemies: [e("examiner", "Examiner", 60, 12, { kind: "emoji", value: "🧠" })],
};

export function pickEncounterForDepth(rng: RNG, depth: number, isBoss: boolean): EncounterDef {
  if (isBoss) return BOSS_ENCOUNTER;

  // Match your vision: 1–3 easy, 4–6 medium, 7+ hard
  const pool =
    depth <= 3 ? ENCOUNTER_POOL_EASY_5 :
    depth <= 6 ? ENCOUNTER_POOL_MED_5 :
    ENCOUNTER_POOL_HARD_5;

  return pick(rng, pool);
}

export function encounterToEnemyStates(enc: EncounterDef): EnemyState[] {
  return enc.enemies.map((x) => ({
    id: x.id,
    name: x.name,
    hp: x.hp,
    maxHP: x.maxHP,
    intentDamage: x.intentDamage,
    sprite: x.sprite,
    statuses: x.statuses ?? [],
  }));
}
