// src/game/state.ts
import { generateMap } from "./map";
import { makeRng } from "./rng";
import type { RunMap, NodeType } from "./map";
import type { BattleState, SpriteRef } from "./battle";
import { startBattle as startBattleCore } from "./battle";
import { encounterToEnemyStates, pickEncounterForDepth } from "../content/enemies";

export type Screen =
  | "TITLE"
  | "OVERWORLD"
  | "SETUP"
  | "NODE"
  | "BATTLE"
  | "REWARD"
  | "VICTORY"
  | "DEFEAT";

export type SetupSelection = {
  characterId: string;
  customAvatarDataUrl?: string | null;
  deckCardIds: string[];
  supplyId: string;
  lunchItemId: string;
  customName?: string | null;   // only used when customAvatarDataUrl exists
  playerName: string;           // always set
  playerSprite?: SpriteRef;     // always set when possible

  deckCardIds: string[];
  supplyId: string;
  lunchItemId: string;
};

export type GameState = {
  screen: Screen;
  seed: number;
  gold: number;

  map?: RunMap;
  currentNodeId?: string;

  setupDone: boolean;
  setup?: SetupSelection | null;

  // Player stats (persist across nodes)
  maxHp: number;
  hp: number;

  // run timer
  runStartMs: number | null;
  runEndMs: number | null;

  // teacher tools
  teacherUnlocked: boolean;

  // node screen
  nodeScreen?: { type: NodeType; depth: number };

  // battle
  battle?: BattleState;

  // last outcome (optional, helpful for end screens)
  lastOutcome?: { type: "victory" | "defeat"; isBoss: boolean } | null;
};

export type Action =
  | { type: "NEW_RUN"; seed?: number }
  | { type: "OPEN_SETUP" }
  | { type: "COMPLETE_SETUP"; setup: SetupSelection }
  | { type: "OPEN_NODE"; nodeId: string }
  | { type: "SET_CURRENT_NODE"; nodeId: string }
  | {
      type: "START_BATTLE";
      nodeId: string;
      isBoss: boolean;
      difficulty: 1 | 2 | 3;
      deckCardIds: string[];
    }
  | { type: "BATTLE_UPDATE"; battle: BattleState }
  | {
      type: "BATTLE_ENDED";
      victory: boolean;
      goldGained: number;
      isBoss: boolean;
      playerHpAfter: number;
    }
  | { type: "CLOSE_NODE" }
  | { type: "CLAIM_REWARD" }
  | { type: "TEACHER_UNLOCK" }
  | { type: "TEACHER_LOCK" };

export const initialState: GameState = {
  screen: "TITLE",
  seed: 12345,
  gold: 0,
  setupDone: false,
  setup: null,

  maxHp: 50,
  hp: 50,

  runStartMs: null,
  runEndMs: null,

  teacherUnlocked: false,
  nodeScreen: undefined,
  battle: undefined,
  lastOutcome: null,
};

// ---------- helpers ----------
function hashStringToInt(str: string): number {
  // simple 32-bit hash (deterministic)
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// Feel free to expand this later once your character roster is real.
const CHARACTER_PRESETS: Record<
  string,
  { name: string; sprite: SpriteRef }
> = {
  default: { name: "Player", sprite: { kind: "emoji", value: "🧑‍🎓" } },
};

function getPlayerPresentation(setup: SetupSelection | null | undefined): {
  playerName: string;
  playerSprite?: SpriteRef;
} {
  if (!setup) return { playerName: "Player", playerSprite: { kind: "emoji", value: "🧑‍🎓" } };

  // custom upload wins
  if (setup.customAvatarDataUrl) {
    return {
      playerName: "Player",
      playerSprite: { kind: "image", src: setup.customAvatarDataUrl, alt: "Player" },
    };
  }

  // preset by characterId (or fallback)
  const preset = CHARACTER_PRESETS[setup.characterId] ?? CHARACTER_PRESETS.default;
  return { playerName: preset.name, playerSprite: preset.sprite };
}

export function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case "NEW_RUN": {
      const seed = action.seed ?? Math.floor(Math.random() * 1_000_000);
      const rng = makeRng(seed);
      const map = generateMap(seed, rng);

      return {
        screen: "OVERWORLD",
        seed,
        gold: 0,
        map,
        currentNodeId: map.startId,

        setupDone: false,
        setup: null,

        maxHp: 50,
        hp: 50,

        runStartMs: Date.now(),
        runEndMs: null,

        teacherUnlocked: state.teacherUnlocked, // keep across restart

        nodeScreen: undefined,
        battle: undefined,
        lastOutcome: null,
      };
    }

    case "TEACHER_UNLOCK":
      return { ...state, teacherUnlocked: true };

    case "TEACHER_LOCK":
      return { ...state, teacherUnlocked: false };

    case "OPEN_SETUP":
      return { ...state, screen: "SETUP" };

    case "COMPLETE_SETUP":
      return { ...state, screen: "OVERWORLD", setupDone: true, setup: action.setup };

    case "OPEN_NODE": {
      if (!state.map) return state;
      const node = state.map.nodes[action.nodeId];
      return {
        ...state,
        currentNodeId: action.nodeId,
        screen: "NODE",
        nodeScreen: { type: node.type, depth: node.depth },
      };
    }

    case "SET_CURRENT_NODE":
      return {
        ...state,
        currentNodeId: action.nodeId,
        screen: "OVERWORLD",
        nodeScreen: undefined,
        battle: undefined,
      };

    case "START_BATTLE": {
      // If you want to force setup first, uncomment:
      // if (!state.setupDone) return state;

      const nodeId = action.nodeId;

      const deckCardIds =
        Array.isArray(action.deckCardIds) && action.deckCardIds.length > 0
          ? action.deckCardIds
          : (state.setup?.deckCardIds ?? []);

      // Deterministic RNG per node (stable for a given run seed + nodeId)
      const nodeSeed = (state.seed ^ hashStringToInt(nodeId)) >>> 0;
      const rng = makeRng(nodeSeed);

      const difficulty = action.difficulty;

      const isBoss = action.isBoss;
      const depth = state.map?.nodes?.[nodeId]?.depth ?? 1;
      const encounter = pickEncounterForDepth(rng, depth, isBoss);
      const enemies = encounterToEnemyStates(encounter);

      const setup = state.setup ?? null;

      const playerHpStart = state.hp;
      const playerMaxHp = state.maxHp;

      // Use setup-provided presentation first
      const playerName =
        (setup?.customAvatarDataUrl
          ? (setup?.customName?.trim() || setup?.playerName || "Player")
          : (setup?.playerName || "Player"));

      const playerSprite =
        setup?.playerSprite ??
        (setup?.customAvatarDataUrl
          ? { kind: "image", src: setup.customAvatarDataUrl, alt: playerName }
          : { kind: "emoji", value: "🧑‍🎓" });

      try {
        const battle = startBattleCore({
          rng,
          difficulty,
          isBoss,
          playerHpStart,
          playerMaxHp,
          deckCardIds,
          enemies,
        
          playerName,
          playerSprite,
        });        

        console.log("✅ START_BATTLE -> screen=BATTLE", {
          nodeId,
          isBoss,
          difficulty,
          deckLen: deckCardIds.length,
          nodeSeed,
        });

        return {
          ...state,
          currentNodeId: nodeId,
          screen: "BATTLE",
          battle,
          nodeScreen: undefined,
        };
      } catch (err) {
        console.error("❌ START_BATTLE failed:", err);
        return state;
      }
    }

    case "BATTLE_UPDATE":
      return { ...state, battle: action.battle };

    case "BATTLE_ENDED": {
      const incoming = Number.isFinite(action.playerHpAfter) ? action.playerHpAfter : state.hp;
      const hpAfter = Math.max(0, Math.min(state.maxHp, incoming));
      const now = Date.now();

      // If dead: immediate defeat screen, stop run timer
      if (hpAfter <= 0) {
        return {
          ...state,
          hp: 0,
          gold: state.gold + action.goldGained,
          screen: "DEFEAT",
          runEndMs: state.runEndMs ?? now,
          battle: undefined,
          lastOutcome: { type: "defeat", isBoss: action.isBoss },
        };
      }

      // If final boss victory: victory screen, stop run timer
      if (action.victory && action.isBoss) {
        return {
          ...state,
          hp: hpAfter,
          gold: state.gold + action.goldGained,
          screen: "VICTORY",
          runEndMs: state.runEndMs ?? now,
          battle: undefined,
          lastOutcome: { type: "victory", isBoss: true },
        };
      }

      // Otherwise: reward placeholder screen
      return {
        ...state,
        hp: hpAfter,
        gold: state.gold + action.goldGained,
        screen: "REWARD",
        battle: undefined,
        lastOutcome: action.victory
          ? { type: "victory", isBoss: false }
          : state.lastOutcome,
      };
    }

    case "CLOSE_NODE":
      return { ...state, screen: "OVERWORLD", nodeScreen: undefined };

    case "CLAIM_REWARD":
      return { ...state, screen: "OVERWORLD" };

    default:
      return state;
  }
}