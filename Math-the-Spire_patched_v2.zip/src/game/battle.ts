// src/game/battle.ts
import type { RNG } from "./rng";
import { getQuestion } from "./questions";
import { ALL_CARDS_40ish } from "../content/cards";
import { applyEndOfTurnTicks, modifyAttackDamage } from "./effects";

export type Difficulty = 1 | 2 | 3;
export type BossMode = "NONE" | "WARD" | "STRIKE";
export type CardType = "ATTACK" | "BLOCK" | "SKILL";

export type SpriteRef =
  | { kind: "emoji"; value: string }
  | { kind: "image"; src: string; alt?: string };

export type Status = {
  id?: string;
  icon?: string;
  label?: string;
  stacks?: number;
};

export type EnemyState = {
  id: string;
  name: string;
  hp: number;
  maxHP: number;
  intentDamage: number;
  sprite?: SpriteRef;
  statuses: Status[];
};

type CardDef = {
  id: string;
  name: string;
  type: CardType;
  desc: string;
};

function normalizeCardType(t: any): CardType {
  const s = String(t ?? "").toUpperCase();
  if (s === "ATTACK") return "ATTACK";
  if (s === "BLOCK") return "BLOCK";
  return "SKILL";
}

const cardById = new Map<string, CardDef>(
  ALL_CARDS_40ish.map((c: any) => [
    c.id,
    {
      id: c.id,
      name: c.name ?? c.id,
      type: normalizeCardType(c.type),
      desc: c.desc ?? "",
    },
  ])
);

function getCardDef(cardId: string): CardDef {
  return (
    cardById.get(cardId) ?? {
      id: cardId,
      name: cardId,
      type: "SKILL",
      desc: "Unknown card",
    }
  );
}

function cardCost(_cardId: string) {
  return 1;
}

function cardEffect(cardId: string): { dmg?: number; block?: number; draw?: number } {
  const def = getCardDef(cardId);
  if (def.type === "ATTACK") return { dmg: 6 };
  if (def.type === "BLOCK") return { block: 6 };
  return { block: 3, draw: 1 };
}

export type BattleState = {
  isBoss: boolean;
  bossMode: BossMode;
  turn: number;

  playerName: string;
  playerSprite?: SpriteRef;
  playerStatuses: Status[];

  playerHP: number;
  playerMaxHP: number;
  playerBlock: number;

  enemies: EnemyState[];
  selectedEnemyId: string;

  enemyHP: number;
  enemyMaxHP: number;
  enemyIntentDamage: number;

  difficulty: Difficulty;

  energy: number;
  maxEnergy: number;

  drawPile: string[];
  hand: string[];
  discardPile: string[];

  awaiting: null | {
    cardId: string;
    question: { prompt: string; answer: string | number; hint?: string };
  };

  lastResult?: { correct: boolean; message: string } | null;
};

function shuffle<T>(rng: RNG, arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function drawOne(state: BattleState, rng: RNG): BattleState {
  let drawPile = state.drawPile.slice();
  let discardPile = state.discardPile.slice();
  const hand = state.hand.slice();

  if (drawPile.length === 0) {
    if (discardPile.length === 0) return state;
    drawPile = shuffle(rng, discardPile);
    discardPile = [];
  }

  const top = drawPile.shift();
  if (!top) return { ...state, drawPile, discardPile };

  hand.push(top);
  return { ...state, drawPile, discardPile, hand };
}

function drawToHandSize(state: BattleState, rng: RNG, target: number): BattleState {
  let next = { ...state };
  while (next.hand.length < target) {
    const before = next.hand.length;
    next = drawOne(next, rng);
    if (next.hand.length === before) break;
  }
  return next;
}

function bossModeForTurn(isBoss: boolean, turn: number): BossMode {
  if (!isBoss) return "NONE";
  return turn % 2 === 1 ? "WARD" : "STRIKE";
}

function aliveEnemies(state: BattleState): EnemyState[] {
  return (state.enemies ?? []).filter((e) => (e.hp ?? 0) > 0);
}

function allEnemiesDefeated(state: BattleState): boolean {
  return aliveEnemies(state).length === 0;
}

function ensureValidTarget(state: BattleState): BattleState {
  const alive = aliveEnemies(state);
  if (alive.length === 0) return state;
  const sel = state.selectedEnemyId;
  const selAlive = alive.some((e) => e.id === sel);
  return selAlive ? state : { ...state, selectedEnemyId: alive[0].id };
}

function setEnemyHPById(state: BattleState, enemyId: string, newHP: number): BattleState {
  const enemies = state.enemies.slice();
  const idx = enemies.findIndex((e) => e.id === enemyId);
  if (idx < 0) return state;

  enemies[idx] = { ...enemies[idx], hp: newHP };

  // Keep legacy fields in sync with the primary (index 0)
  const primary = enemies[0];
  const next: BattleState = {
    ...state,
    enemies,
    selectedEnemyId: primary?.id ?? (enemies[0]?.id ?? "enemy-1"),
    enemyHP: primary?.hp ?? state.enemyHP,
    enemyMaxHP: primary?.maxHP ?? state.enemyMaxHP,
    enemyIntentDamage: primary?.intentDamage ?? state.enemyIntentDamage,
  };

  return ensureValidTarget(next);
}

function setPrimaryEnemyHP(state: BattleState, newHP: number): BattleState {
  const primaryId = state.enemies[0]?.id;
  if (!primaryId) return { ...state, enemyHP: newHP };
  return setEnemyHPById(state, primaryId, newHP);
}

export function startBattle(opts: {
  rng: RNG;
  difficulty: Difficulty;
  isBoss: boolean;
  playerHpStart: number;
  playerMaxHp: number;
  deckCardIds: string[];
  playerName?: string;
  playerSprite?: SpriteRef;
  enemies?: Array<{
    id: string;
    name: string;
    hp: number;
    maxHP: number;
    intentDamage: number;
    sprite?: SpriteRef;
    statuses?: Status[];
  }>;
}): BattleState {
  const { rng, difficulty, isBoss, playerHpStart, playerMaxHp, deckCardIds } = opts;

  const enemyMaxHP = isBoss ? 55 : 32 + (difficulty - 1) * 6;
  const enemyIntentDamage = isBoss ? 10 : 6 + (difficulty - 1) * 2;

  const defaultDeck = ["strike", "strike", "block", "block", "skill"];
  const deck = deckCardIds?.length ? deckCardIds.slice() : defaultDeck.slice();
  while (deck.length < 5) deck.push(defaultDeck[deck.length % defaultDeck.length]);

  const drawPile = shuffle(rng, deck);

  const enemies: EnemyState[] =
    opts.enemies?.length
      ? opts.enemies.map((e) => ({
          id: e.id,
          name: e.name,
          hp: e.hp,
          maxHP: e.maxHP,
          intentDamage: e.intentDamage,
          sprite: e.sprite,
          statuses: e.statuses ?? [],
        }))
      : [
          {
            id: "enemy-1",
            name: isBoss ? "Boss" : "Enemy",
            hp: enemyMaxHP,
            maxHP: enemyMaxHP,
            intentDamage: enemyIntentDamage,
            sprite: { kind: "emoji", value: isBoss ? "👹" : "👾" },
            statuses: [],
          },
        ];

  const primary = enemies[0];

  const base: BattleState = {
    isBoss,
    bossMode: bossModeForTurn(isBoss, 1),
    turn: 1,

    playerName: opts.playerName ?? "Player",
    playerSprite: opts.playerSprite,
    playerStatuses: [],

    playerHP: playerHpStart,
    playerMaxHP: playerMaxHp,
    playerBlock: 0,

    enemies,
    selectedEnemyId: primary?.id ?? (enemies[0]?.id ?? "enemy-1"),

    enemyHP: primary?.hp ?? enemyMaxHP,
    enemyMaxHP: primary?.maxHP ?? enemyMaxHP,
    enemyIntentDamage: primary?.intentDamage ?? enemyIntentDamage,

    difficulty,

    energy: 3,
    maxEnergy: 3,

    drawPile,
    hand: [],
    discardPile: [],

    awaiting: null,
    lastResult: null,
  };

  return drawToHandSize(base, rng, 5);
}

export function chooseCard(state: BattleState, rng: RNG, cardId: string): BattleState {
  state = ensureValidTarget(state);
  if (state.playerHP <= 0 || allEnemiesDefeated(state)) return state;
  if (state.awaiting) return state;

  const cost = cardCost(cardId);
  if (state.energy < cost) {
    return { ...state, lastResult: { correct: false, message: "Not enough energy." } };
  }

  if (state.bossMode === "WARD" && getCardDef(cardId).type !== "BLOCK") {
    return { ...state, lastResult: { correct: false, message: "Boss WARD: play a BLOCK card." } };
  }
  if (state.bossMode === "STRIKE" && getCardDef(cardId).type !== "ATTACK") {
    return { ...state, lastResult: { correct: false, message: "Boss STRIKE: play an ATTACK card." } };
  }

  return {
    ...state,
    awaiting: { cardId, question: getQuestion({ rng, difficulty: state.difficulty }) },
    lastResult: null,
  };
}

export function resolveCardAnswer(opts: { rng: RNG; state: BattleState; input: string }): BattleState {
  const { rng, state, input } = opts;
  if (!state.awaiting) return state;

  const { cardId, question } = state.awaiting;
  const correct = String(input).trim() === String(question.answer).trim();

  let next: BattleState = { ...state, awaiting: null };

  const cost = cardCost(cardId);
  next = { ...next, energy: Math.max(0, next.energy - cost) };

  const idx = next.hand.indexOf(cardId);
  let hand = next.hand.slice();
  let discardPile = next.discardPile.slice();
  if (idx >= 0) {
    hand.splice(idx, 1);
    discardPile.push(cardId);
  }
  next = { ...next, hand, discardPile };

  if (!correct) {
    return { ...next, lastResult: { correct: false, message: "Incorrect — energy spent, card discarded." } };
  }

  const effect = cardEffect(cardId);

  if (effect.dmg) {
    const targetId = next.selectedEnemyId || next.enemies[0]?.id || "enemy-1";
    const target = next.enemies.find((e) => e.id === targetId) ?? next.enemies[0];
    const modified = modifyAttackDamage(effect.dmg, next.playerStatuses, target?.statuses);
    const curHP = target?.hp ?? next.enemyHP;
    const newHP = Math.max(0, curHP - modified);
    next = setEnemyHPById(next, targetId, newHP);
  }
  if (effect.block) {
    next = { ...next, playerBlock: next.playerBlock + effect.block };
  }

  next = {
    ...next,
    lastResult: { correct: true, message: effect.dmg ? "Correct — attack hits!" : "Correct — card played!" },
  };

  if (effect.draw && effect.draw > 0) {
    next = drawToHandSize(next, rng, Math.min(10, next.hand.length + effect.draw));
  }

  return next;
}

export function endTurn(state: BattleState, rng: RNG): BattleState {
  state = ensureValidTarget(state);
  if (state.playerHP <= 0 || allEnemiesDefeated(state)) return state;
  if (state.awaiting) return state;

  // Tick poison/regen etc at end of player turn (before enemies act)
  state = applyEndOfTurnTicks(state);
  if (state.playerHP <= 0 || allEnemiesDefeated(state)) return state;

  const discardPile = [...state.discardPile, ...state.hand];

  // Total intent damage from all living enemies (later this can become per-enemy intents)
  let dmg = 0;
  for (const en of aliveEnemies(state)) {
    dmg += modifyAttackDamage(en.intentDamage ?? 0, en.statuses, state.playerStatuses);
  }
  let block = state.playerBlock;

  const blocked = Math.min(block, dmg);
  block -= blocked;
  dmg -= blocked;

  const playerHP = Math.max(0, state.playerHP - dmg);

  let next: BattleState = {
    ...state,
    hand: [],
    discardPile,
    playerHP,
    playerBlock: 0,
    lastResult: null,
  };

  if (playerHP <= 0) return next;

  const newTurn = next.turn + 1;
  next = { ...next, turn: newTurn, bossMode: bossModeForTurn(next.isBoss, newTurn), energy: next.maxEnergy };

  return drawToHandSize(next, rng, 5);
}

