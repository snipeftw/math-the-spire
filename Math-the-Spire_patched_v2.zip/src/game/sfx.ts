// src/game/sfx.ts
type Wave = OscillatorType;

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

class SfxEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;

  private volume = 0.35;
  private muted = false;

  private lastHoverAt = 0;

  private ensure() {
    if (this.ctx && this.master) return;

    const Ctx = (window.AudioContext || (window as any).webkitAudioContext) as
      | typeof AudioContext
      | undefined;

    if (!Ctx) return;

    const ctx = new Ctx();
    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : this.volume;
    master.connect(ctx.destination);

    this.ctx = ctx;
    this.master = master;
  }

  private async resumeIfNeeded() {
    this.ensure();
    if (!this.ctx) return;
    if (this.ctx.state !== "running") {
      try {
        await this.ctx.resume();
      } catch {
        // ignore
      }
    }
  }

  setVolume(v: number) {
    this.volume = clamp01(v);
    this.ensure();
    if (this.master) this.master.gain.value = this.muted ? 0 : this.volume;
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.ensure();
    if (this.master) this.master.gain.value = this.muted ? 0 : this.volume;
  }

  private async tone(opts: {
    wave?: Wave;
    freq: number;
    durMs: number;
    gain?: number;
    sweepTo?: number;
    attackMs?: number;
    releaseMs?: number;
    detune?: number;
  }) {
    await this.resumeIfNeeded();
    if (!this.ctx || !this.master) return;
    if (this.muted || this.volume <= 0) return;

    const ctx = this.ctx;

    const osc = ctx.createOscillator();
    const g = ctx.createGain();

    osc.type = opts.wave ?? "sine";
    osc.frequency.setValueAtTime(opts.freq, ctx.currentTime);
    if (opts.detune) osc.detune.setValueAtTime(opts.detune, ctx.currentTime);

    if (opts.sweepTo != null) {
      osc.frequency.exponentialRampToValueAtTime(
        Math.max(10, opts.sweepTo),
        ctx.currentTime + opts.durMs / 1000
      );
    }

    const peak = (opts.gain ?? 0.9) * this.volume;
    const attack = (opts.attackMs ?? 6) / 1000;
    const release = (opts.releaseMs ?? 120) / 1000;

    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), ctx.currentTime + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + opts.durMs / 1000 + release);

    osc.connect(g);
    g.connect(this.master);

    osc.start();
    osc.stop(ctx.currentTime + opts.durMs / 1000 + release + 0.02);
  }

  private async dual(opts: {
    wave?: Wave;
    freqA: number;
    freqB: number;
    durMs: number;
    gain?: number;
    sweepToA?: number;
    sweepToB?: number;
  }) {
    await this.resumeIfNeeded();
    if (!this.ctx || !this.master) return;
    if (this.muted || this.volume <= 0) return;

    const ctx = this.ctx;
    const g = ctx.createGain();
    const peak = (opts.gain ?? 0.8) * this.volume;

    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), ctx.currentTime + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + opts.durMs / 1000 + 0.18);

    const oscA = ctx.createOscillator();
    const oscB = ctx.createOscillator();
    oscA.type = opts.wave ?? "sawtooth";
    oscB.type = opts.wave ?? "sawtooth";

    oscA.frequency.setValueAtTime(opts.freqA, ctx.currentTime);
    oscB.frequency.setValueAtTime(opts.freqB, ctx.currentTime);

    if (opts.sweepToA != null) {
      oscA.frequency.exponentialRampToValueAtTime(Math.max(10, opts.sweepToA), ctx.currentTime + opts.durMs / 1000);
    }
    if (opts.sweepToB != null) {
      oscB.frequency.exponentialRampToValueAtTime(Math.max(10, opts.sweepToB), ctx.currentTime + opts.durMs / 1000);
    }

    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(1600, ctx.currentTime);
    lp.frequency.exponentialRampToValueAtTime(700, ctx.currentTime + opts.durMs / 1000);

    oscA.connect(lp);
    oscB.connect(lp);
    lp.connect(g);
    g.connect(this.master);

    oscA.start();
    oscB.start();
    oscA.stop(ctx.currentTime + opts.durMs / 1000 + 0.22);
    oscB.stop(ctx.currentTime + opts.durMs / 1000 + 0.22);
  }
  // light “card flick” on hover (throttled to avoid spam)
  cardHover() {
    const now = Date.now();
    if (now - this.lastHoverAt < 45) return;
    this.lastHoverAt = now;

    this.tone({
      wave: "triangle",
      freq: 1250,
      sweepTo: 900,
      durMs: 22,
      gain: 0.42,
      attackMs: 2,
      releaseMs: 60,
    });
  }

  // select / add
  selectOn() {
    this.tone({
      wave: "sine",
      freq: 620,
      sweepTo: 860,
      durMs: 55,
      gain: 0.75,
      attackMs: 4,
      releaseMs: 120,
    });
  }

  // deselect / remove
  selectOff() {
    this.tone({
      wave: "sine",
      freq: 520,
      sweepTo: 360,
      durMs: 65,
      gain: 0.7,
      attackMs: 4,
      releaseMs: 140,
    });
  }

  click() {
    this.tone({ wave: "triangle", freq: 820, sweepTo: 650, durMs: 45, gain: 0.9, releaseMs: 70 });
  }

  confirm() {
    this.tone({ wave: "sine", freq: 520, sweepTo: 860, durMs: 90, gain: 0.9, releaseMs: 140 });
  }

  bad() {
    this.dual({ wave: "sawtooth", freqA: 220, freqB: 170, sweepToA: 95, sweepToB: 80, durMs: 180, gain: 0.95 });
  }

  win() {
    this.tone({ wave: "sine", freq: 660, durMs: 90, gain: 0.85 });
    setTimeout(() => this.tone({ wave: "sine", freq: 880, durMs: 110, gain: 0.8 }), 90);
    setTimeout(() => this.tone({ wave: "sine", freq: 990, durMs: 130, gain: 0.75 }), 190);
  }

  bossSelect() {
    this.dual({
      wave: "sawtooth",
      freqA: 140,
      freqB: 105,
      sweepToA: 70,
      sweepToB: 55,
      durMs: 260,
      gain: 0.95,
    });

    setTimeout(() => {
      this.dual({
        wave: "square",
        freqA: 90,
        freqB: 60,
        sweepToA: 45,
        sweepToB: 35,
        durMs: 180,
        gain: 0.9,
      });
    }, 230);

    setTimeout(() => {
      this.tone({
        wave: "triangle",
        freq: 520,
        sweepTo: 1040,
        durMs: 160,
        gain: 0.75,
        releaseMs: 180,
      });
    }, 380);
  }

  bossWin() {
    // Big victory: impact + rising fanfare + sparkle tail
    this.dual({ wave: "square", freqA: 120, freqB: 90, sweepToA: 70, sweepToB: 55, durMs: 220, gain: 0.95 });

    const notes = [392, 523, 659, 784, 988]; // G4 C5 E5 G5 B5-ish
    notes.forEach((f, i) => {
      setTimeout(() => {
        this.tone({ wave: "triangle", freq: f, durMs: 140, gain: 0.75, releaseMs: 220 });
        // a faint octave shimmer
        this.tone({ wave: "sine", freq: f * 2, durMs: 110, gain: 0.35, releaseMs: 200, detune: -6 });
      }, 210 + i * 120);
    });

    setTimeout(() => {
      // final “shine”
      this.tone({ wave: "sine", freq: 880, sweepTo: 1760, durMs: 260, gain: 0.55, releaseMs: 420 });
    }, 900);
  }
}

export const sfx = new SfxEngine();
