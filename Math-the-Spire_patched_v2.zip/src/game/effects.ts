// src/game/effects.ts
import type { Status, BattleState, EnemyState } from "./battle";
import { getEffectDef } from "../content/effects";

// ---- Status helpers ----

export function normalizeStatus(id: string, stacks: number): Status {
  const def = getEffectDef(id);
  return {
    id,
    icon: def?.icon ?? "✨",
    label: def ? `${def.name} — ${def.description}` : id,
    stacks,
  };
}

function upsertStatus(list: Status[], id: string, deltaStacks: number): Status[] {
  const next = list.slice();
  const idx = next.findIndex((s) => s.id === id);
  if (idx >= 0) {
    const current = next[idx];
    const stacks = Math.max(0, (current.stacks ?? 0) + deltaStacks);
    if (stacks <= 0) next.splice(idx, 1);
    else next[idx] = { ...current, ...normalizeStatus(id, stacks), stacks };
    return next;
  }
  if (deltaStacks <= 0) return next;
  next.push(normalizeStatus(id, deltaStacks));
  return next;
}

export function addPlayerStatus(state: BattleState, id: string, stacks: number): BattleState {
  return { ...state, playerStatuses: upsertStatus(state.playerStatuses ?? [], id, stacks) };
}

export function addEnemyStatus(state: BattleState, enemyId: string, id: string, stacks: number): BattleState {
  const enemies = state.enemies.map((en) =>
    en.id === enemyId ? { ...en, statuses: upsertStatus(en.statuses ?? [], id, stacks) } : en
  );
  return { ...state, enemies };
}

export function getStacks(statuses: Status[] | undefined, id: string): number {
  return Math.max(0, Number(statuses?.find((s) => s.id === id)?.stacks ?? 0));
}

// ---- Combat modifiers ----
// This is intentionally tiny now, but gives you a real "effects system" foundation.

export function modifyAttackDamage(base: number, attacker: Status[] | undefined, defender: Status[] | undefined): number {
  let dmg = base;

  const weak = getStacks(attacker, "weak");
  if (weak > 0) dmg = Math.floor(dmg * 0.75);

  const vuln = getStacks(defender, "vulnerable");
  if (vuln > 0) dmg = Math.floor(dmg * 1.25);

  return Math.max(0, dmg);
}

// ---- End-of-turn ticking effects ----

function tickList(statuses: Status[]): { next: Status[]; poison: number; regen: number } {
  const poison = getStacks(statuses, "poison");
  const regen = getStacks(statuses, "regen");

  let next = statuses.slice();
  if (poison > 0) next = upsertStatus(next, "poison", -1);
  if (regen > 0) next = upsertStatus(next, "regen", -1);

  return { next, poison, regen };
}

export function applyEndOfTurnTicks(state: BattleState): BattleState {
  // Player
  const pTick = tickList(state.playerStatuses ?? []);
  let playerHP = state.playerHP;
  if (pTick.poison > 0) playerHP = Math.max(0, playerHP - pTick.poison);
  if (pTick.regen > 0) playerHP = Math.min(state.playerMaxHP, playerHP + pTick.regen);

  // Enemies
  const enemies = state.enemies.map((en) => {
    const t = tickList(en.statuses ?? []);
    let hp = en.hp;
    if (t.poison > 0) hp = Math.max(0, hp - t.poison);
    if (t.regen > 0) hp = Math.min(en.maxHP, hp + t.regen);
    return { ...en, statuses: t.next, hp };
  });

  // Keep legacy enemyHP in sync with primary enemy (index 0)
  const enemyHP = enemies[0]?.hp ?? state.enemyHP;

  return { ...state, playerStatuses: pTick.next, playerHP, enemies, enemyHP };
}
