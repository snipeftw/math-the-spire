// src/screens/BattleScreen.tsx
import React, { useMemo, useRef, useState } from "react";
import type { RNG } from "../game/rng";
import type { BattleState } from "../game/battle";
import { chooseCard, resolveCardAnswer, endTurn } from "../game/battle";
import { ALL_CARDS_40ish } from "../content/cards";
import { sfx } from "../game/sfx";
import type { SetupSelection } from "../game/state";
import { SUPPLIES_POOL_10 } from "../content/supplies";
import { CONSUMABLES_10 } from "../content/consumables";

function pct(current: number, max: number) {
  if (max <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((current / max) * 100)));
}

function normalizeType(t: any): "ATTACK" | "BLOCK" | "SKILL" {
  const s = String(t ?? "").toUpperCase();
  if (s === "ATTACK") return "ATTACK";
  if (s === "BLOCK") return "BLOCK";
  return "SKILL";
}

function cardCost(def: any) {
  const n = Number(def?.cost ?? 1);
  return Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 1;
}

function effectText(typeRaw: any) {
  const type = normalizeType(typeRaw);
  if (type === "ATTACK") return "Deal 6";
  if (type === "BLOCK") return "Gain 6 Block";
  return "Gain 3 Block • Draw 1";
}

function SpriteView(props: { sprite?: any; fallbackEmoji: string; alt: string }) {
  const s = props.sprite;

  if (!s) return <div className="entitySprite" aria-hidden>{props.fallbackEmoji}</div>;

  if (s.kind === "emoji") {
    return <div className="entitySprite" aria-hidden>{s.value || props.fallbackEmoji}</div>;
  }

  if (s.kind === "image" && s.src) {
    return (
      <div className="entitySprite entitySpriteImg">
        <img src={s.src} alt={s.alt ?? props.alt} draggable={false} />
      </div>
    );
  }

  if (typeof s === "string") {
    const looksLikeUrl =
      s.startsWith("data:") || s.startsWith("http://") || s.startsWith("https://") || s.startsWith("/");
    if (looksLikeUrl) {
      return (
        <div className="entitySprite entitySpriteImg">
          <img src={s} alt={props.alt} draggable={false} />
        </div>
      );
    }
    return <div className="entitySprite" aria-hidden>{s}</div>;
  }

  return <div className="entitySprite" aria-hidden>{props.fallbackEmoji}</div>;
}

export function BattleScreen(props: {
  rng: RNG;
  battle: BattleState;
  setup?: SetupSelection | null;
  onUpdate: (next: BattleState) => void;
  onEnd: (victory: boolean, goldGained: number, playerHpAfter: number) => void;
}) {
  const b = props.battle;
  const setup = props.setup ?? null;

  const cardById = useMemo(() => new Map(ALL_CARDS_40ish.map((c: any) => [c.id, c])), []);

  const supplyById = useMemo(() => new Map(SUPPLIES_POOL_10.map((s: any) => [s.id, s])), []);
  const consumableById = useMemo(() => new Map(CONSUMABLES_10.map((c: any) => [c.id, c])), []);

  const supply = setup?.supplyId ? supplyById.get(setup.supplyId) : null;
  const consumable = setup?.lunchItemId ? consumableById.get(setup.lunchItemId) : null;

  const [input, setInput] = useState("");

  const enemiesAlive = enemies.some((en: any) => (en.hp ?? 0) > 0);
  const isOver = b.playerHP <= 0 || !enemiesAlive;
  const victory = b.playerHP > 0 && !enemiesAlive;

  const [stagedHandIndex, setStagedHandIndex] = useState<number | null>(null);

  const [draggingIdx, setDraggingIdx] = useState<number | null>(null);
  const [dragOverPlayZone, setDragOverPlayZone] = useState(false);

  const awaiting = b.awaiting;
  const awaitingCardId = awaiting?.cardId ?? null;
  const awaitingCardDef = awaitingCardId ? cardById.get(awaitingCardId) : null;

  const playerMax = b.playerMaxHP ?? 50;
  const enemyMax = b.enemyMaxHP ?? (b.isBoss ? 55 : 32);

  const forced = b.bossMode === "WARD" ? "BLOCK" : b.bossMode === "STRIKE" ? "ATTACK" : null;

  const topDiscardId = b.discardPile.length ? b.discardPile[b.discardPile.length - 1] : null;
  const topDiscardDef = topDiscardId ? cardById.get(topDiscardId) : null;

  const draggingCardId = draggingIdx != null ? b.hand[draggingIdx] : null;
  const draggingDef = draggingCardId ? cardById.get(draggingCardId) : null;

  function canPlay(cardTypeRaw: any, cost: number) {
    const cardType = normalizeType(cardTypeRaw);
    if (isOver) return false;
    if (awaiting) return false;
    if (b.energy < cost) return false;
    if (b.bossMode === "WARD" && cardType !== "BLOCK") return false;
    if (b.bossMode === "STRIKE" && cardType !== "ATTACK") return false;
    return true;
  }

  function stageCard(i: number) {
    if (awaiting || isOver) return;
    const cardId = b.hand[i];
    if (!cardId) return;

    const def = cardById.get(cardId);
    const cost = cardCost(def);
    if (!canPlay(def?.type, cost)) return;

    sfx.select();
    setStagedHandIndex(i);
  }

  function playIndex(i: number) {
    if (awaiting || isOver) return;
    const cardId = b.hand[i];
    if (!cardId) return;

    const def = cardById.get(cardId);
    const cost = cardCost(def);
    if (!canPlay(def?.type, cost)) return;

    const next = chooseCard(b, props.rng, cardId);
    props.onUpdate(next);

    setStagedHandIndex(null);
    setInput("");
  }

  function submitAnswer() {
    if (!awaiting) return;
    sfx.confirm();
    const next = resolveCardAnswer({ rng: props.rng, state: b, input });
    props.onUpdate(next);
    setInput("");
  }

  function endMyTurn() {
    if (awaiting) return;
    sfx.click();
    const next = endTurn(b, props.rng);
    props.onUpdate(next);
    setInput("");
    setStagedHandIndex(null);
  }

  function onDropPlayZone(e: React.DragEvent) {
    e.preventDefault();
    setDragOverPlayZone(false);

    const raw =
      e.dataTransfer.getData("application/x-hand-index") ||
      e.dataTransfer.getData("text/plain");

    const idx = Number(raw);
    if (!Number.isFinite(idx)) return;

    playIndex(idx);
    setDraggingIdx(null);
    clearDragImage();
  }

  // ----- Drag image helpers (makes dragging look like the actual card) -----
  const dragImgRef = useRef<HTMLElement | null>(null);

  function clearDragImage() {
    if (dragImgRef.current) {
      dragImgRef.current.remove();
      dragImgRef.current = null;
    }
  }

  function setRealCardDragImage(e: React.DragEvent<HTMLElement>, el: HTMLElement) {
    clearDragImage();

    const clone = el.cloneNode(true) as HTMLElement;
    clone.style.position = "fixed";
    clone.style.left = "-9999px";
    clone.style.top = "-9999px";
    clone.style.pointerEvents = "none";
    clone.style.opacity = "1";
    clone.style.transform = "none";
    clone.style.width = `${el.getBoundingClientRect().width}px`;
    clone.style.height = `${el.getBoundingClientRect().height}px`;

    document.body.appendChild(clone);
    dragImgRef.current = clone;

    e.dataTransfer.setDragImage(
      clone,
      Math.round(clone.getBoundingClientRect().width / 2),
      Math.round(clone.getBoundingClientRect().height / 2)
    );
  }

  // --- Energy badge ---
  const EnergyBadge = (
    <span
      className="badge"
      style={{
        width: 170,
        justifyContent: "center",
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 12px",
        border: "1px solid rgba(255,255,255,0.20)",
        background: "rgba(120,140,255,0.12)",
      }}
      title="Energy (spent to play cards)"
    >
      <span style={{ fontSize: 16, transform: "translateY(-1px)" }}>⚡</span>
      <span style={{ fontWeight: 900 }}>
        {b.energy}/{b.maxEnergy}
      </span>
      <span style={{ display: "inline-flex", gap: 4, marginLeft: 2 }}>
        {Array.from({ length: b.maxEnergy }).map((_, i) => (
          <span
            key={i}
            style={{
              width: 10,
              height: 10,
              borderRadius: 999,
              border: "1px solid rgba(255,255,255,0.25)",
              background: i < b.energy ? "rgba(34,197,94,0.85)" : "rgba(255,255,255,0.08)",
              boxShadow: i < b.energy ? "0 0 0 2px rgba(34,197,94,0.12)" : "none",
            }}
          />
        ))}
      </span>
    </span>
  );

  const playZoneHint = awaiting
    ? "Submit your answer below."
    : draggingIdx != null
      ? (dragOverPlayZone ? "Release to play" : "Drag here to play")
      : "Drop a card here to play it";

  // Enemies list (fallback to legacy single enemy)
  const enemies =
    (b as any).enemies?.length
      ? ((b as any).enemies as any[])
      : [
          {
            id: "enemy-1",
            name: b.isBoss ? "Boss" : "Enemy",
            hp: b.enemyHP,
            maxHP: enemyMax,
            intentDamage: b.enemyIntentDamage,
            sprite: { kind: "emoji", value: b.isBoss ? "👹" : "👾" },
            statuses: [],
          },
        ];

  return (
    <div className="container battleLayout">
      <div className="battleMain">
        <div className="header">
          <div>
            <h2 className="h2">{b.isBoss ? "Boss Battle" : "Battle"}</h2>
            <div className="sub">
              Turn <strong>{b.turn}</strong>
              {b.isBoss && (
                <>
                  {" "}
                  • Boss Mode <strong>{b.bossMode}</strong>
                </>
              )}
            </div>
          </div>

          <div className="row">
            <span className={"badge " + (b.isBoss ? "warn" : "good")}>
              Intent: <strong>Attack {b.enemyIntentDamage}</strong>
            </span>
          </div>
        </div>

        <div className="grid two">
          {/* Player */}
          <div className="panel">
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                <SpriteView sprite={(b as any).playerSprite} fallbackEmoji="🧑‍🎓" alt={b.playerName || "Player"} />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {b.playerName ?? "Player"}
                  </div>
                </div>
              </div>

              <span className="badge">
                Block <strong>{b.playerBlock}</strong>
              </span>
            </div>

            <div style={{ marginTop: 10 }}>
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div className="muted">HP</div>
                <div>
                  <strong>{b.playerHP}</strong> / {playerMax}
                </div>
              </div>
              <div className="bar" style={{ marginTop: 6 }}>
                <div className="barFill" style={{ width: `${pct(b.playerHP, playerMax)}%` }} />
              </div>
            </div>

            <div className="statusRow" style={{ marginTop: 10 }}>
              {((b as any).playerStatuses ?? []).map((s: any, i: number) => (
                <div key={s.id ?? i} className="statusChip" title={s.label ?? s.id ?? "Status"}>
                  <span className="statusIcon" aria-hidden>{s.icon ?? "✨"}</span>
                  {typeof s.stacks === "number" && <span className="statusStacks">{s.stacks}</span>}
                </div>
              ))}
            </div>

            {forced && !isOver && (
              <div style={{ marginTop: 12 }}>
                <span className={"badge " + (forced === "ATTACK" ? "good" : "warn")}>
                  Forced: <strong>{forced}</strong>
                </span>
              </div>
            )}
          </div>

          {/* Enemies */}
          <div className="panel">
            <div
              className="enemyGrid"
              style={{
                display: "grid",
                gap: 12,
                gridTemplateColumns: enemies.length > 1 ? "repeat(2, minmax(0, 1fr))" : "1fr",
              }}
            >
              {enemies.map((en: any) => {
                const hpPct = pct(en.hp, en.maxHP);
                const statuses = (en.statuses ?? []) as any[];

                return (
                  <div
                      key={en.id}
                      className="enemyCard"
                      onClick={() => {
                        if (!isOver) props.onUpdate({ ...(b as any), selectedEnemyId: en.id } as any);
                      }}
                      style={{
                        cursor: isOver ? "default" : "pointer",
                        outline: en.id === (b as any).selectedEnemyId ? "2px solid rgba(255,255,255,0.65)" : "none",
                        outlineOffset: 2,
                      }}
                    >
                    <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                        <SpriteView sprite={en.sprite} fallbackEmoji="👾" alt={en.name || "Enemy"} />
                        <div style={{ fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {en.name ?? "Enemy"}
                        </div>
                      </div>
                    </div>

                    {/* Intent under sprite/name */}
                    <div className="enemyIntent" style={{ marginTop: 8 }}>
                      <span className="badge warn">
                        Intent <strong>{en.intentDamage ?? b.enemyIntentDamage}</strong>
                      </span>
                    </div>

                    <div style={{ marginTop: 10 }}>
                      <div className="row" style={{ justifyContent: "space-between" }}>
                        <div className="muted">HP</div>
                        <div>
                          <strong>{en.hp}</strong> / {en.maxHP}
                        </div>
                      </div>
                      <div className="bar" style={{ marginTop: 6 }}>
                        <div className="barFill" style={{ width: `${hpPct}%` }} />
                      </div>
                    </div>

                    <div className="statusRow" style={{ marginTop: 10 }}>
                      {statuses.map((s, i) => (
                        <div key={s.id ?? i} className="statusChip" title={s.label ?? s.id ?? "Status"}>
                          <span className="statusIcon" aria-hidden>{s.icon ?? "✨"}</span>
                          {typeof s.stacks === "number" && <span className="statusStacks">{s.stacks}</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* PLAY / QUESTION */}
        <div className="panel soft">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div style={{ fontWeight: 900, fontSize: 18 }}>{awaiting ? "Question" : ""}</div>
            <span className="badge">
              Difficulty <strong>{b.difficulty}</strong>
            </span>
          </div>

          {awaiting ? (
            <>
              {awaitingCardDef && (
                <div
                  className="panel soft"
                  style={{
                    marginTop: 12,
                    border: "1px solid rgba(34,197,94,0.30)",
                    background: "rgba(34,197,94,0.05)",
                    textAlign: "left",
                  }}
                >
                  <div style={{ fontWeight: 900, fontSize: 13 }}>{awaitingCardDef.name}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>
                    {normalizeType(awaitingCardDef.type)} • {effectText(awaitingCardDef.type)}
                  </div>
                </div>
              )}

              <div style={{ fontSize: 18, marginTop: 10 }}>{awaiting.question.prompt}</div>
              {awaiting.question.hint && (
                <div className="muted" style={{ marginTop: 10 }}>
                  Hint: {awaiting.question.hint}
                </div>
              )}
            </>
          ) : (
            <div className="muted" style={{ marginTop: 10, fontSize: 13 }}>
              Drag a card into the play area (or tap/click a card, then tap the play area).
            </div>
          )}

          {!isOver ? (
            <>
              <hr className="sep" />

              <div
                className={
                  "playZone " +
                  (dragOverPlayZone ? "playZoneHot " : "") +
                  (!awaiting && draggingIdx != null ? "playZoneArmed" : "")
                }
                onDragEnter={() => {
                  if (!awaiting) setDragOverPlayZone(true);
                }}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.dataTransfer.dropEffect = "move";
                  if (!awaiting) setDragOverPlayZone(true);
                }}
                onDragLeave={() => setDragOverPlayZone(false)}
                onDrop={onDropPlayZone}
                onClick={() => {
                  if (!awaiting && stagedHandIndex != null) playIndex(stagedHandIndex);
                }}
                title={awaiting ? "Answer the question first." : "Drop a card here to play it."}
                style={{ userSelect: "none" }}
              >
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontWeight: 900 }}>{awaiting ? "Answering…" : "PLAY AREA"}</div>

                  {!awaiting && (
                    <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
                      {playZoneHint}
                    </div>
                  )}

                  {!awaiting && draggingDef && dragOverPlayZone && (
                    <div
                      className="panel soft"
                      style={{
                        marginTop: 10,
                        width: "min(320px, 100%)",
                        textAlign: "left",
                        border: "1px solid rgba(34,197,94,0.35)",
                      }}
                    >
                      <div style={{ fontWeight: 900, fontSize: 13 }}>{draggingDef.name}</div>
                      <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>
                        {normalizeType(draggingDef.type)}
                      </div>
                      <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>
                        {effectText(draggingDef.type)}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div style={{ height: 12 }} />

              <div className="row" style={{ justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <div className="row">
                  <input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={awaiting ? "Type your answer (number)" : "Play a card first"}
                    className="input"
                    disabled={!awaiting}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") submitAnswer();
                    }}
                  />
                  <button className="btn primary" onClick={submitAnswer} disabled={!awaiting}>
                    Submit
                  </button>
                </div>

                <button className="btn" onClick={endMyTurn} disabled={!!awaiting}>
                  End Turn
                </button>
              </div>

              {b.lastResult && (
                <div style={{ marginTop: 12 }}>
                  <span className={"badge " + (b.lastResult.correct ? "good" : "bad")}>
                    {b.lastResult.message}
                  </span>
                </div>
              )}
            </>
          ) : (
            <>
              <hr className="sep" />
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div style={{ fontSize: 20, fontWeight: 900 }}>{victory ? "Victory ✅" : "Defeat ❌"}</div>
                <button
                  className={"btn " + (victory ? "primary" : "danger")}
                  onClick={() => {
                    const gold = victory ? (b.isBoss ? 30 : 12) : 0;
                    props.onEnd(victory, gold, b.playerHP);
                  }}
                >
                  Continue
                </button>
              </div>
            </>
          )}
        </div>

        <div style={{ height: 12 }} />

        {/* HAND PANEL */}
        <div className="panel handPanel">
          <div className="handTopRow">
            {/* DRAW */}
            <div className="pileWrap" title={`Draw pile (${b.drawPile.length})`}>
              <div className="pileLabel">Draw</div>
              <div className="pile">
                <div className="pileCard back" />
                <div className="pileCount">{b.drawPile.length}</div>
              </div>
            </div>

            {/* ENERGY */}
            <div className="energyCenter">{EnergyBadge}</div>

            {/* DISCARD */}
            <div className="pileWrap" title={`Discard pile (${b.discardPile.length})`}>
              <div className="pileLabel">Discard</div>
              <div className="pile">
                <div className="pileCard face">
                  {topDiscardDef ? (
                    <>
                      <div style={{ fontWeight: 900, fontSize: 12 }}>{topDiscardDef.name ?? topDiscardId}</div>
                      <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>
                        {effectText(topDiscardDef.type)}
                      </div>
                    </>
                  ) : (
                    <div className="muted" style={{ fontSize: 12 }}>Empty</div>
                  )}
                </div>
                <div className="pileCount">{b.discardPile.length}</div>
              </div>
            </div>
          </div>

          <div className="handTitle">Hand</div>

          <div className="handCardsGrid">
            {b.hand.map((cardId, idx) => {
              const def = cardById.get(cardId);
              const name = def?.name ?? cardId;
              const type = normalizeType(def?.type);
              const desc = def?.desc ?? "";

              const cost = cardCost(def);
              const playable = canPlay(type, cost);

              const disabledReason =
                awaiting
                  ? "Answer the current question first."
                  : b.energy < cost
                    ? "Not enough energy."
                    : b.bossMode === "WARD" && type !== "BLOCK"
                      ? "Boss WARD: BLOCK only."
                      : b.bossMode === "STRIKE" && type !== "ATTACK"
                        ? "Boss STRIKE: ATTACK only."
                        : "";

              return (
                <div key={`${cardId}_${idx}`} className="handCardWrap">
                  <div
                    className={"handCard panel soft cardTile " + (playable ? "cardPlayable" : "cardDisabled")}
                    draggable={playable && !awaiting && !isOver}
                    onMouseEnter={() => sfx.cardHover()}
                    onDragStart={(e) => {
                      if (!playable || awaiting || isOver) return;

                      e.dataTransfer.setData("application/x-hand-index", String(idx));
                      e.dataTransfer.setData("text/plain", String(idx));
                      e.dataTransfer.effectAllowed = "move";

                      setRealCardDragImage(e, e.currentTarget as HTMLElement);
                      setDraggingIdx(idx);
                    }}
                    onDragEnd={() => {
                      setDraggingIdx(null);
                      setDragOverPlayZone(false);
                      clearDragImage();
                    }}
                    onClick={() => stageCard(idx)}
                    title={playable ? `${name} • ${effectText(type)}\n${desc}` : disabledReason}
                    role="button"
                    tabIndex={0}
                    style={{
                      textAlign: "left",
                      opacity: playable ? 1 : 0.55,
                      cursor: playable ? "grab" : "not-allowed",
                      userSelect: "none",
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 900, fontSize: 13 }}>{name}</div>
                        <div className="muted" style={{ fontSize: 11, marginTop: 2 }}>{type}</div>
                      </div>

                      <span className="badge" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <span>{cost}</span>
                        <span style={{ opacity: 0.9 }}>⚡</span>
                      </span>
                    </div>

                    <div className="muted" style={{ fontSize: 11, marginTop: 8 }}>
                      {effectText(type)}
                    </div>

                    <div className="muted handCardDesc">{desc}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* SIDEBAR */}
      <aside className="panel battleSide">
        <div style={{ fontSize: 16, fontWeight: 900 }}>Loadout</div>

        <div style={{ marginTop: 10, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div className="panel soft">
            <div className="muted" style={{ fontSize: 12 }}>Supply</div>
            <div style={{ marginTop: 8, display: "flex", gap: 10, alignItems: "center" }}>
              <div style={{ fontSize: 22 }}>{supply?.emoji ?? "📎"}</div>
              <div>
                <div style={{ fontWeight: 900, fontSize: 13 }}>{supply?.name ?? "—"}</div>
                <div className="muted" style={{ fontSize: 11 }}>{supply?.desc ?? ""}</div>
              </div>
            </div>
          </div>

          <div className="panel soft">
            <div className="muted" style={{ fontSize: 12 }}>Consumable</div>
            <div style={{ marginTop: 8, display: "flex", gap: 10, alignItems: "center" }}>
              <div style={{ fontSize: 22 }}>{consumable?.emoji ?? "🍎"}</div>
              <div>
                <div style={{ fontWeight: 900, fontSize: 13 }}>{consumable?.name ?? "—"}</div>
                <div className="muted" style={{ fontSize: 11 }}>{consumable?.desc ?? ""}</div>
              </div>
            </div>
          </div>
        </div>

        {(!supply || !consumable) && (
          <div className="muted" style={{ marginTop: 10, fontSize: 12 }}>
            (These are pulled from your setup selection.)
          </div>
        )}
      </aside>
    </div>
  );
}
