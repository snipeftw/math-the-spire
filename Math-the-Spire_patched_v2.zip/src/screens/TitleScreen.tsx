// src/screens/TitleScreen.tsx
import React, { useState } from "react";

export function TitleScreen(props: { onStart: (seed?: number) => void }) {
  const [seedText, setSeedText] = useState("");

  return (
    <div style={styles.wrap}>
      <h1 style={styles.h1}>Math Roguelike (Framework)</h1>
      <p style={styles.p}>
        Start a run. Leave seed blank for random. Seed makes maps/questions repeatable.
      </p>

      <div style={styles.row}>
        <input
          value={seedText}
          onChange={(e) => setSeedText(e.target.value)}
          placeholder="Seed (optional)"
          style={styles.input}
        />
        <button
          style={styles.btn}
          onClick={() => {
            const n = seedText.trim() === "" ? undefined : Number(seedText);
            props.onStart(Number.isFinite(n as number) ? (n as number) : undefined);
          }}
        >
          Start Run
        </button>
      </div>
    </div>
  );
}

const styles: Record<string, React.CSSProperties> = {
  wrap: { maxWidth: 900, margin: "40px auto", padding: 16, fontFamily: "system-ui" },
  h1: { margin: 0, fontSize: 32 },
  p: { opacity: 0.85, lineHeight: 1.4 },
  row: { display: "flex", gap: 8, marginTop: 12 },
  input: { flex: 1, padding: 10, fontSize: 16 },
  btn: { padding: "10px 14px", fontSize: 16, cursor: "pointer" },
};
