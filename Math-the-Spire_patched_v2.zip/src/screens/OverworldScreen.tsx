// src/screens/OverworldScreen.tsx
import React, { useMemo } from "react";
import type { RunMap, MapNode, NodeType } from "../game/map";

type Pos = { x: number; y: number };

function iconFor(type: NodeType) {
  switch (type) {
    case "START": return "🏠";
    case "FIGHT": return "⚔️";
    case "EVENT": return "❓";
    case "REST": return "🔥";
    case "SHOP": return "🛒";
    case "BOSS": return "👑";
    default: return "•";
  }
}

export function OverworldScreen(props: {
  map: RunMap;
  currentNodeId: string;
  setupDone: boolean;
  gold: number;

  onClickStart: () => void;
  onOpenNode: (node: MapNode) => void;
}) {
  const { nodes, startId, bossDepth } = props.map;
  const current = nodes[props.currentNodeId];

  // Only next nodes are clickable; before setup is done only START is clickable
  const nextIds = new Set(current.next);
  const canClick = (n: MapNode) => {
    if (!props.setupDone) return n.id === startId;
    return nextIds.has(n.id);
  };

  // Layout constants
  const W = 1000;
  const rowH = 84;
  const topPad = 56;
  const sidePad = 90;

  const depthGroups = useMemo(() => {
    const byDepth: Record<number, MapNode[]> = {};
    Object.values(nodes).forEach((n) => {
      (byDepth[n.depth] ??= []).push(n);
    });
    Object.keys(byDepth).forEach((k) => byDepth[Number(k)].sort((a, b) => a.id.localeCompare(b.id)));
    return byDepth;
  }, [nodes]);

  // ✅ Invert Y so START (depth 0) is at bottom, BOSS at top
  const positions = useMemo(() => {
    const pos: Record<string, Pos> = {};
    for (let d = 0; d <= bossDepth; d++) {
      const row = depthGroups[d] ?? [];
      const count = row.length;
      for (let i = 0; i < count; i++) {
        const x = sidePad + ((W - sidePad * 2) * (i + 1)) / (count + 1);
        const y = topPad + (bossDepth - d) * rowH; // inverted
        pos[row[i].id] = { x, y };
      }
    }
    return pos;
  }, [depthGroups, bossDepth]);

  const H = topPad + bossDepth * rowH + 90;

  const edges = useMemo(() => {
    const lines: Array<{ from: Pos; to: Pos; active: boolean }> = [];
    Object.values(nodes).forEach((n) => {
      const from = positions[n.id];
      n.next.forEach((toId) => {
        const to = positions[toId];
        if (!from || !to) return;

        // Highlight edges from current node
        const active = n.id === props.currentNodeId;
        lines.push({ from, to, active });
      });
    });
    return lines;
  }, [nodes, positions, props.currentNodeId]);

  return (
    <div className="container">
      <div className="header">
        <div>
          <h2 className="h2">Overworld</h2>
          <div className="sub">
            Gold <strong>{props.gold}</strong> • Current: <strong>{current.type}</strong> (Depth {current.depth})
          </div>
        </div>

        <div className="mapLegend">
          <span className="badge">Start <strong>🏠</strong></span>
          <span className="badge good">Next <strong>●</strong></span>
          <span className="badge warn">Boss <strong>👑</strong></span>
        </div>
      </div>

      <div className="panel mapFrame">
        <svg className="mapSvg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          {edges.map((e, idx) => (
            <line
              key={idx}
              x1={e.from.x}
              y1={e.from.y}
              x2={e.to.x}
              y2={e.to.y}
              stroke={e.active ? "rgba(34,197,94,0.65)" : "rgba(255,255,255,0.12)"}
              strokeWidth={e.active ? 4 : 2}
              strokeLinecap="round"
            />
          ))}
        </svg>

        {Object.values(nodes).map((n) => {
          const p = positions[n.id];
          if (!p) return null;

          const isBoss = n.type === "BOSS";
          const isStart = n.type === "START";

          const cls =
            "mapNode " +
            (isBoss ? "boss " : "") +
            (n.id === props.currentNodeId ? "current " : "") +
            (canClick(n) ? "next " : "");

          return (
            <button
              key={n.id}
              className={cls}
              style={{ left: `${(p.x / W) * 100}%`, top: `${(p.y / H) * 100}%` }}
              disabled={!canClick(n)}
              title={`${n.type} • Depth ${n.depth}`}
              onClick={() => {
                if (isStart) props.onClickStart();
                else props.onOpenNode(n);
              }}
            >
              <div style={{ fontSize: 22, transform: "translateY(1px)" }}>
                {iconFor(n.type)}
              </div>
            </button>
          );
        })}
      </div>

      <div style={{ marginTop: 12 }} className="muted">
        You can only travel forward. Each run randomizes node types + connections, but keeps 10 sets before the boss.
      </div>
    </div>
  );
}
