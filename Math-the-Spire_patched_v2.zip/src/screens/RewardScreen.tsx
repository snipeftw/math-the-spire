// src/screens/RewardScreen.tsx
import React from "react";

export function RewardScreen(props: { gold: number; onContinue: () => void }) {
  return (
    <div className="container">
      <div className="header">
        <div>
          <h2 className="h2">Rewards</h2>
          <div className="sub">Take your loot and keep climbing.</div>
        </div>
        <span className="badge good">
          Total Gold <strong>{props.gold}</strong>
        </span>
      </div>

      <div className="panel">
        <div style={{ fontWeight: 900, fontSize: 18 }}>Run Status</div>
        <div className="muted" style={{ marginTop: 6 }}>
          (Next we can add: relic choices, upgrades, and a summary of what happened.)
        </div>

        <hr className="sep" />

        <button className="btn primary" onClick={props.onContinue}>
          Back to Map
        </button>
      </div>
    </div>
  );
}
