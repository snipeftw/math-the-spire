// src/screens/NodeScreen.tsx
import React from "react";
import type { NodeType } from "../game/map";

export function NodeScreen(props: {
  type: NodeType;
  depth: number;
  onComplete: () => void;
}) {
  const title =
    props.type === "EVENT" ? "Event" :
    props.type === "REST" ? "Rest" :
    props.type === "SHOP" ? "Shop" :
    props.type;

  return (
    <div className="container">
      <div className="header">
        <div>
          <h2 className="h2">{title}</h2>
          <div className="sub">
            Depth <strong>{props.depth}</strong> • Placeholder screen (we’ll fill this in).
          </div>
        </div>
        <span className="badge">Type: <strong>{props.type}</strong></span>
      </div>

      <div className="panel">
        <div style={{ fontWeight: 900, fontSize: 18 }}>Coming soon</div>
        <div className="muted" style={{ marginTop: 6 }}>
          This will eventually contain the actual {title.toLowerCase()} content.
        </div>

        <hr className="sep" />

        <button className="btn primary" onClick={props.onComplete}>
          Continue
        </button>
      </div>
    </div>
  );
}
