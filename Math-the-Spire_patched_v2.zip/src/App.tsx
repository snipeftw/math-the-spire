// src/App.tsx
import React, { useEffect, useMemo, useReducer, useState } from "react";
import { initialState, reducer } from "./game/state";

import { TitleScreen } from "./screens/TitleScreen";
import { OverworldScreen } from "./screens/OverworldScreen";
import { SetupScreen } from "./screens/SetupScreen";
import { NodeScreen } from "./screens/NodeScreen";
import { BattleScreen } from "./screens/BattleScreen";
import { RewardScreen } from "./screens/RewardScreen";

import { makeRng } from "./game/rng";
import type { MapNode } from "./game/map";

import { sfx } from "./game/sfx";

import { CHARACTERS_3 } from "./content/characters";
import { SUPPLIES_POOL_10 } from "./content/supplies";
import { CONSUMABLES_10 } from "./content/consumables";
import { ALL_CARDS_40ish } from "./content/cards";

const TEACHER_PASS = "dsp";
const TEACHER_UNLOCK_KEY = "math-roguelike-teacher-unlocked";
const BEST_TIME_KEY = "math-roguelike-best-ms";

const SFX_VOL_KEY = "math-roguelike-sfx-vol";
const SFX_MUTE_KEY = "math-roguelike-sfx-mute";

function loadBestMs(): number | null {
  try {
    const raw = localStorage.getItem(BEST_TIME_KEY);
    if (!raw) return null;
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n : null;
  } catch {
    return null;
  }
}
function saveBestMs(ms: number) {
  try {
    localStorage.setItem(BEST_TIME_KEY, String(ms));
  } catch {}
}

function loadTeacherUnlocked(): boolean {
  try {
    return localStorage.getItem(TEACHER_UNLOCK_KEY) === "1";
  } catch {
    return false;
  }
}
function saveTeacherUnlocked(on: boolean) {
  try {
    localStorage.setItem(TEACHER_UNLOCK_KEY, on ? "1" : "0");
  } catch {}
}

function loadSfxVol() {
  try {
    const n = Number(localStorage.getItem(SFX_VOL_KEY));
    return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.35;
  } catch {
    return 0.35;
  }
}
function loadSfxMute() {
  try {
    return localStorage.getItem(SFX_MUTE_KEY) === "1";
  } catch {
    return false;
  }
}
function saveSfxVol(v: number) {
  try {
    localStorage.setItem(SFX_VOL_KEY, String(v));
  } catch {}
}
function saveSfxMute(m: boolean) {
  try {
    localStorage.setItem(SFX_MUTE_KEY, m ? "1" : "0");
  } catch {}
}

function formatDuration(ms: number) {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${m}:${ss}`;
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const [now, setNow] = useState(() => Date.now());
  const [bestMs, setBestMs] = useState<number | null>(() => loadBestMs());

  const [sfxVol, setSfxVol] = useState(() => loadSfxVol());
  const [sfxMuted, setSfxMuted] = useState(() => loadSfxMute());

  const [showDeck, setShowDeck] = useState(false);

  const charById = useMemo(() => new Map(CHARACTERS_3.map((c) => [c.id, c])), []);
  const supplyById = useMemo(() => new Map(SUPPLIES_POOL_10.map((s) => [s.id, s])), []);
  const consumableById = useMemo(() => new Map(CONSUMABLES_10.map((c) => [c.id, c])), []);
  const cardById = useMemo(() => new Map(ALL_CARDS_40ish.map((c) => [c.id, c])), []);

  const setup = state.setup ?? null;

  function deckCounts() {
    const ids = setup?.deckCardIds ?? [];
    const counts = new Map<string, number>();
    for (const id of ids) counts.set(id, (counts.get(id) ?? 0) + 1);

    const rows = Array.from(counts.entries())
      .map(([id, count]) => {
        const def = cardById.get(id);
        return { id, count, name: def?.name ?? id, type: def?.type ?? "?" };
      })
      .sort((a, b) => (a.type + a.name).localeCompare(b.type + b.name));

    return rows;
  }

  const DeckModal = !showDeck ? null : (
    <div
      onClick={() => setShowDeck(false)}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        background: "rgba(0,0,0,0.7)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        padding: 16,
      }}
    >
      <div
        className="panel"
        onClick={(e) => e.stopPropagation()}
        style={{ width: "min(760px, 100%)", maxHeight: "80vh", overflow: "auto" }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 18, fontWeight: 800 }}>Your Deck</div>
          <button className="btn" onClick={() => setShowDeck(false)}>Close</button>
        </div>

        <div className="muted" style={{ marginTop: 6, fontSize: 12 }}>
          {setup?.deckCardIds?.length ?? 0} cards total
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 8 }}>
          {deckCounts().map((r) => {
            const def = cardById.get(r.id);
            const name = def?.name ?? r.id;
            const type = def?.type ?? "?";
            const desc = def?.desc ?? "";

            return (
              <div
                key={r.id}
                className="panel soft deck-row"
                onMouseEnter={() => sfx.cardHover()}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  gap: 12,
                  alignItems: "flex-start",
                }}
              >
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 800 }}>{name}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 2 }}>{type}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 8 }}>{desc}</div>
                </div>

                <div className="badge">
                  x <strong>{r.count}</strong>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  // Boss intro overlay state
  const [bossIntro, setBossIntro] = useState<null | { nodeId: string; difficulty: 1 | 2 | 3 }>(null);

  const rng = useMemo(() => makeRng(state.seed), [state.seed]);

  useEffect(() => {
    sfx.setVolume(sfxVol);
    sfx.setMuted(sfxMuted);
    saveSfxVol(sfxVol);
    saveSfxMute(sfxMuted);
  }, [sfxVol, sfxMuted]);

  useEffect(() => {
    if (loadTeacherUnlocked()) dispatch({ type: "TEACHER_UNLOCK" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const running = state.runStartMs != null && state.runEndMs == null && state.screen !== "TITLE";
    if (!running) return;

    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [state.runStartMs, state.runEndMs, state.screen]);

  useEffect(() => {
    if (state.runStartMs == null || state.runEndMs == null) return;
    const finalMs = state.runEndMs - state.runStartMs;
    if (finalMs <= 0) return;

    setBestMs((prev) => {
      const stored = loadBestMs();
      const currentBest = prev ?? stored;
      if (currentBest == null || finalMs < currentBest) {
        saveBestMs(finalMs);
        return finalMs;
      }
      return currentBest;
    });
  }, [state.runStartMs, state.runEndMs]);

  // Boss intro: enter boss battle (FIXED: includes deckCardIds)
  const startBossBattleNow = (payload: { nodeId: string; difficulty: 1 | 2 | 3 }) => {
    setBossIntro(null);
    dispatch({
      type: "START_BATTLE",
      nodeId: payload.nodeId,
      isBoss: true,
      difficulty: payload.difficulty,
      deckCardIds: state.setup?.deckCardIds ?? [],
    });
  };

  // Boss intro auto-advance (ONLY for teacher testing)
  useEffect(() => {
    if (!bossIntro) return;
    if (!state.teacherUnlocked) return;

    const t = window.setTimeout(() => startBossBattleNow(bossIntro), 700);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bossIntro, state.teacherUnlocked]);

  const restartRun = () => {
    setBossIntro(null);
    sfx.confirm();
    dispatch({ type: "NEW_RUN" });
  };

  const elapsedMs = state.runStartMs == null ? 0 : (state.runEndMs ?? now) - state.runStartMs;

  const timerBadge = (
    <span className={"badge " + (state.runEndMs ? "good" : "")}>
      Run Time <strong>{formatDuration(elapsedMs)}</strong>
    </span>
  );

  const bestBadge = (
    <span className="badge">
      Best <strong>{bestMs == null ? "—" : formatDuration(bestMs)}</strong>
    </span>
  );

  const teacherUnlock = () => {
    const entered = window.prompt("Teacher passcode:");
    if (entered == null) return;

    if (entered === TEACHER_PASS) {
      sfx.confirm();
      saveTeacherUnlocked(true);
      dispatch({ type: "TEACHER_UNLOCK" });
    } else {
      sfx.bad();
      window.alert("Incorrect passcode.");
    }
  };

  const teacherLock = () => {
    sfx.click();
    saveTeacherUnlocked(false);
    dispatch({ type: "TEACHER_LOCK" });
  };

  const skipToNext = () => {
    if (!state.map || !state.currentNodeId) return;
    const node = state.map.nodes[state.currentNodeId];
    const next = node.next?.[0];
    if (!next) {
      sfx.bad();
      window.alert("No next node to skip to from here.");
      return;
    }
    sfx.click();
    dispatch({ type: "SET_CURRENT_NODE", nodeId: next });
  };

  const winBattle = () => {
    const isBoss = state.battle?.isBoss ?? false;

    if (isBoss) sfx.bossWin();
    else sfx.win();

    const goldGained = isBoss ? 30 : 12;
    const playerHpAfter = state.battle?.playerHP ?? state.hp;

    dispatch({
      type: "BATTLE_ENDED",
      victory: true,
      goldGained,
      isBoss,
      playerHpAfter,
    });
  };

  const sfxControls = (
    <span className="badge" style={{ display: "inline-flex", gap: 10, alignItems: "center" }}>
      <button
        className="btn"
        onClick={() => {
          const next = !sfxMuted;
          setSfxMuted(next);
          if (!next) sfx.click();
        }}
        title={sfxMuted ? "Unmute SFX" : "Mute SFX"}
      >
        {sfxMuted ? "🔇" : "🔊"}
      </button>

      <span className="muted" style={{ fontSize: 12 }}>SFX</span>

      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={sfxVol}
        onChange={(e) => setSfxVol(Number(e.target.value))}
        style={{ width: 120 }}
        title="SFX Volume"
      />
    </span>
  );

  const bossOverlay = bossIntro ? (
    <div
      onClick={() => startBossBattleNow(bossIntro)}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        background: "radial-gradient(circle at 50% 40%, rgba(255,255,255,0.10), rgba(0,0,0,0.92))",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
        cursor: "pointer",
      }}
    >
      <div
        className="panel"
        style={{
          maxWidth: 720,
          width: "100%",
          textAlign: "center",
          border: "1px solid rgba(255,255,255,0.18)",
          boxShadow: "0 20px 80px rgba(0,0,0,0.55)",
        }}
      >
        <div style={{ fontSize: 12, letterSpacing: 2, opacity: 0.85 }}>FINAL ENCOUNTER</div>
        <div style={{ fontSize: 44, fontWeight: 800, marginTop: 6, lineHeight: 1.05 }}>
          THE FINAL BOSS
        </div>
        <div style={{ marginTop: 10, opacity: 0.85 }}>The Grand Equation awaits.</div>

        <div style={{ display: "flex", gap: 10, justifyContent: "center", marginTop: 18, flexWrap: "wrap" }}>
          <button
            className="btn primary"
            onClick={(e) => {
              e.stopPropagation();
              startBossBattleNow(bossIntro);
            }}
          >
            Enter Boss
          </button>
          <button
            className="btn"
            onClick={(e) => {
              e.stopPropagation();
              setBossIntro(null);
            }}
          >
            Cancel
          </button>
        </div>

        <div className="muted" style={{ marginTop: 10, fontSize: 12 }}>
          (click anywhere to enter)
        </div>
      </div>
    </div>
  ) : null;

  const TopBar = (label: string, opts?: { showSkip?: boolean; showWinBattle?: boolean }) => (
    <div className="container" style={{ paddingBottom: 0 }}>
      <div
        className="panel soft"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <div className="row">
          <span className="badge">{label}</span>
          {timerBadge}
          {bestBadge}
          {sfxControls}
          <span className="badge">
            Seed <strong>{state.seed}</strong>
          </span>
          <span className={"badge " + (state.teacherUnlocked ? "warn" : "")}>
            Teacher <strong>{state.teacherUnlocked ? "ON" : "OFF"}</strong>
          </span>
        </div>

        <div className="row">
          {state.teacherUnlocked ? (
            <>
              {opts?.showSkip && (
                <button className="btn" onClick={skipToNext}>
                  Skip to Next
                </button>
              )}
              {opts?.showWinBattle && (
                <button className="btn" onClick={winBattle} title="Instantly win this battle (testing)">
                  Win Battle
                </button>
              )}
              <button className="btn" onClick={teacherLock}>
                Lock Teacher
              </button>
            </>
          ) : (
            <button className="btn" onClick={teacherUnlock}>
              Teacher Unlock
            </button>
          )}

          <button className="btn danger" onClick={restartRun}>
            Restart Run
          </button>
        </div>
      </div>
    </div>
  );

  // ---------- Screens ----------
  if (state.screen === "TITLE") {
    return (
      <div>
        {bossOverlay}
        <TitleScreen onStart={(seed) => dispatch({ type: "NEW_RUN", seed })} />
      </div>
    );
  }

  if (state.screen === "VICTORY") {
    const elapsedMs2 = state.runStartMs && state.runEndMs ? state.runEndMs - state.runStartMs : null;

    return (
      <div>
        {bossOverlay}
        {TopBar("Victory")}
        <div className="container">
          <div className="panel">
            <div style={{ fontSize: 28, fontWeight: 900 }}>🏆 You Win!</div>
            <div className="muted" style={{ marginTop: 8 }}>
              You cleared the run.
            </div>

            <div style={{ marginTop: 12 }} className="row">
              <span className="badge">
                HP <strong>{state.hp}/{state.maxHp}</strong>
              </span>
              <span className="badge">
                Gold <strong>{state.gold}</strong>
              </span>
              {elapsedMs2 != null && (
                <span className="badge">
                  Time <strong>{Math.floor(elapsedMs2 / 1000)}s</strong>
                </span>
              )}
              <span className="badge">
                Seed <strong>{state.seed}</strong>
              </span>
            </div>

            <div style={{ marginTop: 18 }} className="row">
              <button
                className="btn primary"
                onClick={() => {
                  sfx.confirm();
                  dispatch({ type: "NEW_RUN" });
                }}
              >
                Start New Run
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (state.screen === "DEFEAT") {
    const elapsedMs2 = state.runStartMs && state.runEndMs ? state.runEndMs - state.runStartMs : null;

    return (
      <div>
        {bossOverlay}
        {TopBar("Defeat")}
        <div className="container">
          <div className="panel">
            <div style={{ fontSize: 28, fontWeight: 900 }}>💀 You Died</div>
            <div className="muted" style={{ marginTop: 8 }}>
              The run ends here. (No continuing after death.)
            </div>

            <div style={{ marginTop: 12 }} className="row">
              <span className="badge">
                HP <strong>{state.hp}/{state.maxHp}</strong>
              </span>
              <span className="badge">
                Gold <strong>{state.gold}</strong>
              </span>
              {elapsedMs2 != null && (
                <span className="badge">
                  Time <strong>{Math.floor(elapsedMs2 / 1000)}s</strong>
                </span>
              )}
              <span className="badge">
                Seed <strong>{state.seed}</strong>
              </span>
            </div>

            <div style={{ marginTop: 18 }} className="row">
              <button
                className="btn primary"
                onClick={() => {
                  sfx.confirm();
                  dispatch({ type: "NEW_RUN" });
                }}
              >
                Restart Run
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!state.map || !state.currentNodeId) {
    return (
      <div className="container">
        {bossOverlay}
        <div className="panel">
          Missing map.{" "}
          <button className="btn primary" onClick={() => dispatch({ type: "NEW_RUN" })}>
            Start Run
          </button>
        </div>
      </div>
    );
  }

  if (state.screen === "OVERWORLD") {
    const char = setup ? charById.get(setup.characterId) : null;
    const supply = setup ? supplyById.get(setup.supplyId) : null;
    const lunch = setup ? consumableById.get(setup.lunchItemId) : null;

    return (
      <div>
        {bossOverlay}
        {TopBar("Overworld", {
          showSkip: state.teacherUnlocked && state.setupDone,
        })}

        <div style={{ paddingRight: 360 }}>
          <OverworldScreen
            map={state.map}
            currentNodeId={state.currentNodeId}
            setupDone={state.setupDone}
            gold={state.gold}
            onClickStart={() => {
              sfx.click();
              dispatch({ type: "OPEN_SETUP" });
            }}
            onOpenNode={(node: MapNode) => openNode(node)}
          />
        </div>

        <aside
          className="panel"
          style={{
            position: "fixed",
            right: 16,
            top: 120,
            width: 320,
            maxHeight: "calc(100vh - 140px)",
            overflow: "auto",
            zIndex: 50,
          }}
        >
          <div style={{ fontSize: 16, fontWeight: 800 }}>Run Loadout</div>

          <div style={{ marginTop: 10 }} className="row">
            <span className="badge">
              HP <strong>{state.hp}/{state.maxHp}</strong>
            </span>
            <span className="badge">
              Gold <strong>{state.gold}</strong>
            </span>
          </div>

          {!setup ? (
            <div className="muted" style={{ marginTop: 8 }}>
              Complete setup to see your character, supplies, and deck.
            </div>
          ) : (
            <>
              <div className="panel soft" style={{ marginTop: 10 }}>
                <div className="muted" style={{ fontSize: 12 }}>Character</div>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginTop: 6 }}>
                  {setup.customAvatarDataUrl ? (
                    <img
                      src={setup.customAvatarDataUrl}
                      alt="Avatar"
                      style={{ width: 46, height: 46, borderRadius: 12, objectFit: "cover" }}
                    />
                  ) : (
                    <div style={{ fontSize: 34 }}>{char?.emoji ?? "🙂"}</div>
                  )}
                  <div>
                    <div style={{ fontWeight: 800 }}>{char?.name ?? setup.characterId}</div>
                    <div className="muted" style={{ fontSize: 12 }}>
                      {setup.customAvatarDataUrl ? "Custom Avatar" : "Preset"}
                    </div>
                  </div>
                </div>
              </div>

              <div className="panel soft" style={{ marginTop: 10 }}>
                <div className="muted" style={{ fontSize: 12 }}>School Supply</div>
                <div style={{ fontWeight: 800, marginTop: 6 }}>{supply?.name ?? setup.supplyId}</div>
                <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>{supply?.desc ?? ""}</div>
              </div>

              <div className="panel soft" style={{ marginTop: 10 }}>
                <div className="muted" style={{ fontSize: 12 }}>Consumables</div>
                <div style={{ marginTop: 6 }}>
                  <div style={{ fontWeight: 800 }}>{lunch?.name ?? setup.lunchItemId}</div>
                  <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
                    {lunch?.desc ?? ""} <br />
                    <span className="muted">(Later: max 3 carried)</span>
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
                <button className="btn primary" onClick={() => { sfx.click(); setShowDeck(true); }}>
                  View Deck
                </button>
              </div>
            </>
          )}
        </aside>

        {DeckModal}
      </div>
    );
  }

  if (state.screen === "SETUP") {
    return (
      <div>
        {bossOverlay}
        {TopBar("Starting Area")}
        <SetupScreen
          seed={state.seed}
          teacherUnlocked={state.teacherUnlocked}
          onComplete={(setup2) => {
            sfx.confirm();
            dispatch({ type: "COMPLETE_SETUP", setup: setup2 });
          }}
        />
      </div>
    );
  }

  if (state.screen === "NODE" && state.nodeScreen) {
    return (
      <div>
        {bossOverlay}
        {TopBar(`Node • ${state.nodeScreen.type} (Depth ${state.nodeScreen.depth})`, {
          showSkip: state.teacherUnlocked,
        })}
        <NodeScreen
          type={state.nodeScreen.type}
          depth={state.nodeScreen.depth}
          onComplete={() => {
            sfx.confirm();
            dispatch({ type: "CLOSE_NODE" });
          }}
        />
      </div>
    );
  }

  if (state.screen === "BATTLE") {
    if (!state.battle) {
      return (
        <div className="container">
          {TopBar("Battle")}
          <div className="panel">
            <div style={{ fontWeight: 900, fontSize: 18 }}>Battle failed to load</div>
            <div className="muted" style={{ marginTop: 8 }}>
              state.screen is BATTLE but state.battle is missing.
            </div>
            <div className="muted" style={{ marginTop: 8 }}>
              Open DevTools Console for the START_BATTLE log/error.
            </div>
            <button
              className="btn primary"
              onClick={() => dispatch({ type: "CLAIM_REWARD" })}
            >
              Back to Overworld
            </button>
          </div>
        </div>
      );
    }
  
    return (
      <div>
        {bossOverlay}
        {TopBar(`Battle${state.battle.isBoss ? " • BOSS" : ""}`, {
          showWinBattle: state.teacherUnlocked,
        })}
        <BattleScreen
  rng={rng}
  battle={state.battle}
  setup={state.setup} // ✅ add this
  onUpdate={(next) => dispatch({ type: "BATTLE_UPDATE", battle: next })}
  onEnd={(victory, goldGained, playerHpAfter) => {
    const isBoss = state.battle?.isBoss ?? false;

    if (victory && isBoss) sfx.bossWin();
    else if (victory) sfx.win();
    else sfx.bad();

    dispatch({
      type: "BATTLE_ENDED",
      victory,
      goldGained,
      isBoss,
      playerHpAfter,
    });
  }}
/>
      </div>
    );
  }  

  if (state.screen === "REWARD") {
    return (
      <div>
        {bossOverlay}
        {TopBar("Rewards")}
        <RewardScreen
          gold={state.gold}
          onContinue={() => {
            sfx.confirm();
            dispatch({ type: "CLAIM_REWARD" });
          }}
        />
      </div>
    );
  }

  return null;

  // ---------- Node open logic ----------
  function openNode(node: MapNode) {
    const difficulty: 1 | 2 | 3 = node.depth <= 3 ? 1 : node.depth <= 7 ? 2 : 3;

    if (node.type === "BOSS") {
      sfx.bossSelect();
      setBossIntro({ nodeId: node.id, difficulty });
      return;
    }

    if (node.type === "FIGHT") {
      sfx.confirm();
      dispatch({
        type: "START_BATTLE",
        nodeId: node.id,
        isBoss: false,
        difficulty,
        deckCardIds: state.setup?.deckCardIds ?? [],
      });
      return;
    }    

    sfx.click();
    dispatch({ type: "OPEN_NODE", nodeId: node.id });
  }
}
